const Express = require('express')
const myRouter = Express.Router();

const userCustomizedTripsschema = require('../../schema/user/userCustomizedTrips')

myRouter.get('/Display', async (req, res) => {
    try {
        const userData = await userCustomizedTripsschema.find();
        res.status(200).send(userData)
    } catch (error) {
        res.status(404).send('Error:', error)
    }
})

myRouter.post('/Upload', async (req, res) => {
    const { userEmail, bidDescription, Open } = req.body;
    try {
        const postData = new userCustomizedTripsschema({
            userEmail, bidDescription, Open
        })
        const dataCheck = await postData.save();
        if (dataCheck) {
            res.status(201).send('Record Saved')
        }
    } catch (error) {
        res.status(500).send('error', error)
    }
})

module.exports = myRouter;