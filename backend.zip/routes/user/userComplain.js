const Express=require('express')
const myRouter=Express.Router();

const userComplainSchema=require('../../schema/user/userComplain')

myRouter.get('/Display', async (req,res)=>{
    try {
        const c=await userComplainSchema.find()
        res.status(200)
        res.send(c)
    } catch (error) {
        res.status(500).send('Error:',error)
    }
})

myRouter.post('/Upload', async(req,res)=>{
    try {
        const {userId,userName,complainType,complainDetails }=req.body;
        const postData=new userComplainSchema({
            userId,userName,complainType,complainDetails
        })
       const c = await postData.save()
       if(c)
       {
        res.status(201)
        res.send(c)
       }
    } catch (error) {
        res.send(error)
        res.status(400)
    }
})

module.exports=myRouter;