const Express=require('express')
const myRouter=Express.Router()
const adminDetailsSchema=require('../../schema/admin/adminDetails')

const multer = require('multer');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'Uploads/Admin');
  },
  filename: function (req, file, cb) {
    
   cb(null, Date.now() +'_'+  file.originalname);
  }
});

const upload = multer({ storage: storage });

myRouter.post('/Upload',upload.single('UserPhoto'),async(req,res)=>{
    
  let UserPhoto=(req.file)?req.file.filename:null;
      const{adminName,adminId,adminEmail,adminPassword}=req.body;
      const postData=new adminDetailsSchema({
          adminName,adminId,adminEmail,adminPassword,UserPhoto
      })
     let c= await postData.save()
     {
      if(c)
      {
          return res.status(201).send(c)
      }
     }
   
})

myRouter.get('/Display',async(req,res)=>{
    try {
        const c=await adminDetailsSchema.find()
        res.status(200).send(c)
    } catch (error) {
        res.status(404).send('Error:',error)        
    }
})

module.exports=myRouter