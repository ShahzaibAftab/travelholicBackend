const mongoose=require('mongoose')
const userComplain=new mongoose.Schema({

    userId:{
        type:String,
        required:true
    },
    userName:{
        type:String
    },
    complainType:{
        type:String
    },
    complainDetails:{
        type:String
    }

});
module.exports=mongoose.model('userComplains',userComplain)
